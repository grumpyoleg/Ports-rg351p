package main

import (
	"bytes"
	"crypto/sha1"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"
)

const (
	connHost = "localhost"
	connPort = "8083"
	connType = "tcp"
)

func handler1(w http.ResponseWriter, r *http.Request) {
	fmt.Printf("handler1 triggered\n")
	res := []byte("{\"name\":\"svko-pool-1\",\"ip\":\"5.230.69.132\",\"port\":6000,\"success\":true}")
	w.Write(res)
}

func handler2(w http.ResponseWriter, r *http.Request) {
	fmt.Printf("handler2 triggered\n")
	res := []byte("{\"name\":\"svko-pool-2\",\"ip\":\"5.230.69.132\",\"port\":6002,\"success\":true}")
	w.Write(res)
}

func handler3(w http.ResponseWriter, r *http.Request) {
	fmt.Printf("handler3 triggered\n")
	res := []byte("{\"name\":\"beyond-pool-2\",\"ip\":\"50.112.145.154\",\"port\":6002,\"success\":true}")
	w.Write(res)
}

func handler4(w http.ResponseWriter, r *http.Request) {
	fmt.Printf("handler4 triggered\n")
	res := []byte("{\"name\":\"beyond-pool-3\",\"ip\":\"35.173.194.122\",\"port\":6000,\"success\":true}")
	w.Write(res)
}

func handler5(w http.ResponseWriter, r *http.Request) {
	fmt.Printf("handler5 triggered\n")
	res := []byte("{\"name\":\"null-pool-1\",\"ip\":\"5.230.70.190\",\"port\":6000,\"success\":true}")
	w.Write(res)
}

func handler6(w http.ResponseWriter, r *http.Request) {
	fmt.Printf("handler6 triggered\n")
	res := []byte("{\"name\":\"pulse-pool-4\",\"ip\":\"149.91.88.18\",\"port\":2813,\"success\":true}")
	w.Write(res)
}

func handler7(w http.ResponseWriter, r *http.Request) {
	fmt.Printf("handler7 triggered\n")
	res := []byte("{\"name\":\"pulse-pool-1\",\"ip\":\"149.91.88.18\",\"port\":1224,\"success\":true}")
	w.Write(res)
}

func startMinig() {
	fmt.Printf("waiting for mining requests on port %d...\n", minerPort)
	l, err := net.Listen(connType, connHost+":"+fmt.Sprintf("%d", minerPort))
	if err != nil {
		fmt.Println("Error listening:", err.Error())
		os.Exit(1)
	}
	defer l.Close()

	for {
		c, err := l.Accept()
		if err != nil {
			fmt.Println("Error connecting:", err.Error())
			return
		}
		fmt.Println("Client connected. Handling connection")
		go handleConnection(c)
	}
}

var minerPort int32
var poolServicePort int32

func main() {
	fmt.Printf("Duinocoin AVR Mining Emulator\n")
	fmt.Printf("usage: avr_miner <miner port>  \"optional\" <pool serivce port>\n")

	if len(os.Args) == 3 {
		tmp, err := strconv.ParseInt(os.Args[1], 10, 32)
		if err != nil {
			fmt.Printf("ERROR: invalid mining port\n")
			os.Exit(1)
		}
		minerPort = int32(tmp)
		tmp, err = strconv.ParseInt(os.Args[2], 10, 32)
		if err != nil {
			fmt.Printf("ERROR: invalid pool service port\n")
			os.Exit(1)
		}
		poolServicePort = int32(tmp)
	} else if len(os.Args) == 2 {
		tmp, err := strconv.ParseInt(os.Args[1], 10, 32)
		if err != nil {
			fmt.Printf("ERROR: invalid mining port\n")
			os.Exit(1)
		}
		minerPort = int32(tmp)
		poolServicePort = 0
	} else {
		fmt.Printf("ERROR: You must specify the mining port\n")
		os.Exit(1)
	}

	if poolServicePort != 0 {
		go startMinig()
		http.HandleFunc("/1", handler1)
		http.HandleFunc("/2", handler2)
		http.HandleFunc("/3", handler3)
		http.HandleFunc("/4", handler4)
		http.HandleFunc("/5", handler5)
		http.HandleFunc("/6", handler6)
		http.HandleFunc("/7", handler7)
		fmt.Printf("spawning pool service on port %d...\n", poolServicePort)
		log.Fatal(http.ListenAndServe(fmt.Sprintf(":%d", poolServicePort), nil))
	} else {
		fmt.Printf("Pool Serivce not specified\n")
		startMinig()
	}

}

func ducos1a(lastbockhash string, newblockhash string, difficulty uint16) (result uint16) {
	job := make([]byte, 104)

	newblockhash = strings.ToUpper(newblockhash)
	c := []byte(newblockhash)
	final_len := len(newblockhash) >> 1
	i := 0
	for j := 0; j < final_len; j++ {
		job[j] = ((((c[i] & 0x1F) + 9) % 25) << 4) + ((c[i+1]&0x1F)+9)%25
		i += 2
	}

	if difficulty > 655 {
		return 0
	}

	var ducos1res uint16
	for ducos1res = 0; ducos1res < difficulty*100+1; ducos1res++ {
		hasher := sha1.New()
		strToHash := fmt.Sprintf("%s%d", lastbockhash, ducos1res)
		hasher.Write([]byte(strToHash))
		calculatedHash := hasher.Sum(nil)
		if bytes.Equal(calculatedHash, job[0:20]) {
			return ducos1res
		}
	}

	return 0
}

func handleConnection(conn net.Conn) {
	startTime := time.Now()

	// Read all incoming data until 0x0A
	buf := make([]byte, 0, 4096)
	tmp := make([]byte, 256)
	for {
		n, err := conn.Read(tmp)
		if err != nil {
			if err != io.EOF {
				fmt.Println("read error:", err)
			}
			break
		}
		buf = append(buf, tmp[:n]...)
		if buf[len(buf)-1] == 0x0A {
			break
		}
	}

	s := strings.Split(string(buf), ",")
	lastblockhash := s[0]
	newblockhash := s[1]
	difficulty := s[2]
	diffUint, _ := strconv.ParseUint(difficulty, 10, 16)
	fmt.Printf("Received mining request\nlastblockhash: %s\nnewblockhash: %s\ndifficulty: %s\n", lastblockhash, newblockhash, difficulty)

	ducos1result := ducos1a(lastblockhash, newblockhash, uint16(diffUint))
	ducos1result64 := uint64(ducos1result)
	endTime := time.Since(startTime)

	if ducos1result64 > 0 {
		// Nano can compute 194 hashes per sec, so let's calculate how
		// long would a nano have take to find the result and wait that time
		// before returing the result
		secsfloat := float32((float32(ducos1result64) / float32(195)) * 1000)
		secsint := int(secsfloat)
		fmt.Printf("Nano would have taken: %d milliseconds", secsint)
		// lets wait the milliseconds
		time.Sleep((time.Millisecond * time.Duration(secsint)) - endTime)
	}

	endTime = time.Since(startTime)
	res := fmt.Sprintf("%s,%s,%s\n", strconv.FormatUint(ducos1result64, 2), strconv.FormatInt(int64(endTime.Microseconds()), 2), "DUCOID3736353931092118")
	fmt.Printf("elapsed time: %d\n", endTime.Milliseconds())
	fmt.Printf("Result: %s\n", res)
	conn.Write([]byte(res))
	conn.Close()
}
